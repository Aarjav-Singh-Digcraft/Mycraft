//
//  initialize.hpp
//  Mycraft
//
//  Created by Clapeysron on 14/11/2017.
//  Copyright © 2017 Clapeysron. All rights reserved.
//

#ifndef initialize_hpp
#define initialize_hpp

#include <stdio.h>

#endif /* initialize_hpp */
