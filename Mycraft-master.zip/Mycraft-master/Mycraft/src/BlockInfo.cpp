//
//  BlockInfo.cpp
//  Mycraft
//
//  Created by Clapeysron on 28/12/2017.
//  Copyright © 2017 Clapeysron. All rights reserved.
//

#include "BlockInfo.hpp"
std::map<char, BlockInfo> BlockInfoMap;
